// Si más adelante deseas animar o cambiar texto, aquí va la lógica
document.addEventListener("DOMContentLoaded", () => {
  console.log("Página 'Nosotros' cargada correctamente.");
});
