package org.proyecto_integrador.woofandbarf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WoofandbarfApplicationTests {

	@Test
	void contextLoads() {
	}

}
